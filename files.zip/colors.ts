/**
 * colors.ts — Design Token: Color Palette
 * ─────────────────────────────────────────────────────────────────────────────
 * Single source of truth for every color used across the app.
 * These map 1-to-1 with tailwind.config.js so Tailwind classes and
 * raw StyleSheet usage stay in sync.
 *
 * Usage:
 *   import { colors } from '@/theme/colors';
 *   style={{ backgroundColor: colors.primary[500] }}
 * ─────────────────────────────────────────────────────────────────────────────
 */

export const colors = {
  // ─── Brand ─────────────────────────────────────────────────────────────────
  primary: {
    50:  '#EEF2FF',
    100: '#E0E7FF',
    200: '#C7D2FE',
    300: '#A5B4FC',
    400: '#818CF8',
    500: '#6366F1', // ◀ primary CTA
    600: '#4F46E5',
    700: '#4338CA',
    800: '#3730A3',
    900: '#312E81',
    950: '#1E1B4B',
  },

  // ─── Accent / Highlight ────────────────────────────────────────────────────
  accent: {
    50:  '#FFF7ED',
    100: '#FFEDD5',
    300: '#FCD34D',
    400: '#FBBF24',
    500: '#F59E0B', // ◀ accent CTA / badges
    600: '#D97706',
  },

  // ─── Neutral / Grays ───────────────────────────────────────────────────────
  neutral: {
    0:   '#FFFFFF',
    50:  '#F9FAFB',
    100: '#F3F4F6',
    200: '#E5E7EB',
    300: '#D1D5DB',
    400: '#9CA3AF',
    500: '#6B7280',
    600: '#4B5563',
    700: '#374151',
    800: '#1F2937',
    900: '#111827',
    950: '#030712',
  },

  // ─── Semantic ──────────────────────────────────────────────────────────────
  success: {
    50:  '#F0FDF4',
    100: '#DCFCE7',
    500: '#22C55E',
    600: '#16A34A',
    700: '#15803D',
  },
  warning: {
    50:  '#FFFBEB',
    100: '#FEF3C7',
    500: '#EAB308',
    600: '#CA8A04',
    700: '#A16207',
  },
  error: {
    50:  '#FEF2F2',
    100: '#FEE2E2',
    500: '#EF4444',
    600: '#DC2626',
    700: '#B91C1C',
  },
  info: {
    50:  '#EFF6FF',
    100: '#DBEAFE',
    500: '#3B82F6',
    600: '#2563EB',
    700: '#1D4ED8',
  },

  // ─── Absolute ──────────────────────────────────────────────────────────────
  white:       '#FFFFFF',
  black:       '#000000',
  transparent: 'transparent',
} as const;

// ─── Semantic Aliases (ready-to-use in components) ──────────────────────────
export const semanticColors = {
  // Backgrounds
  bgBase:      colors.neutral[50],
  bgSurface:   colors.neutral[0],
  bgSubtle:    colors.neutral[100],
  bgInverse:   colors.neutral[900],

  // Text
  textPrimary:    colors.neutral[900],
  textSecondary:  colors.neutral[600],
  textTertiary:   colors.neutral[400],
  textDisabled:   colors.neutral[300],
  textInverse:    colors.neutral[0],
  textOnPrimary:  colors.neutral[0],

  // Border
  borderDefault: colors.neutral[200],
  borderStrong:  colors.neutral[300],
  borderFocus:   colors.primary[500],

  // Interactive
  interactivePrimary:       colors.primary[500],
  interactivePrimaryHover:  colors.primary[600],
  interactivePrimaryActive: colors.primary[700],

  interactiveSecondary:       colors.neutral[100],
  interactiveSecondaryHover:  colors.neutral[200],
  interactiveSecondaryActive: colors.neutral[300],
} as const;

// ─── Type Exports ─────────────────────────────────────────────────────────────
export type ColorScale   = typeof colors;
export type SemanticColors = typeof semanticColors;
