/** @type {import('tailwindcss').Config} */
module.exports = {
  // NativeWind v4: scan all source files
  content: [
    './App.{js,jsx,ts,tsx}',
    './src/**/*.{js,jsx,ts,tsx}',
  ],

  presets: [require('nativewind/preset')],

  theme: {
    extend: {
      // ─── Brand Colors ────────────────────────────────────────────────────────
      colors: {
        primary: {
          50:  '#EEF2FF',
          100: '#E0E7FF',
          200: '#C7D2FE',
          300: '#A5B4FC',
          400: '#818CF8',
          500: '#6366F1', // main
          600: '#4F46E5',
          700: '#4338CA',
          800: '#3730A3',
          900: '#312E81',
          950: '#1E1B4B',
        },
        accent: {
          50:  '#FFF7ED',
          100: '#FFEDD5',
          300: '#FCD34D',
          400: '#FBBF24',
          500: '#F59E0B', // main
          600: '#D97706',
        },
        neutral: {
          0:   '#FFFFFF',
          50:  '#F9FAFB',
          100: '#F3F4F6',
          200: '#E5E7EB',
          300: '#D1D5DB',
          400: '#9CA3AF',
          500: '#6B7280',
          600: '#4B5563',
          700: '#374151',
          800: '#1F2937',
          900: '#111827',
          950: '#030712',
        },
        success: {
          50:  '#F0FDF4',
          500: '#22C55E',
          600: '#16A34A',
        },
        warning: {
          50:  '#FFFBEB',
          500: '#EAB308',
          600: '#CA8A04',
        },
        error: {
          50:  '#FEF2F2',
          500: '#EF4444',
          600: '#DC2626',
        },
        info: {
          50:  '#EFF6FF',
          500: '#3B82F6',
          600: '#2563EB',
        },
      },

      // ─── Spacing Scale (8-pt grid) ───────────────────────────────────────────
      spacing: {
        px:  '1px',
        0:   '0px',
        0.5: '2px',
        1:   '4px',
        1.5: '6px',
        2:   '8px',
        2.5: '10px',
        3:   '12px',
        3.5: '14px',
        4:   '16px',
        5:   '20px',
        6:   '24px',
        7:   '28px',
        8:   '32px',
        9:   '36px',
        10:  '40px',
        11:  '44px',
        12:  '48px',
        14:  '56px',
        16:  '64px',
        20:  '80px',
        24:  '96px',
        28:  '112px',
        32:  '128px',
      },

      // ─── Border Radius ────────────────────────────────────────────────────────
      borderRadius: {
        none: '0',
        xs:   '4px',
        sm:   '6px',
        md:   '8px',
        lg:   '12px',
        xl:   '16px',
        '2xl':'20px',
        '3xl':'24px',
        full: '9999px',
      },

      // ─── Font Families ────────────────────────────────────────────────────────
      fontFamily: {
        sans:   ['Inter_400Regular', 'System'],
        medium: ['Inter_500Medium', 'System'],
        semibold:['Inter_600SemiBold', 'System'],
        bold:   ['Inter_700Bold', 'System'],
        mono:   ['SpaceMono_400Regular', 'Courier New'],
      },

      // ─── Font Sizes (type scale) ──────────────────────────────────────────────
      fontSize: {
        '2xs': ['10px', { lineHeight: '14px', letterSpacing: '0.4px' }],
        xs:    ['12px', { lineHeight: '16px', letterSpacing: '0.2px' }],
        sm:    ['14px', { lineHeight: '20px', letterSpacing: '0.1px' }],
        md:    ['16px', { lineHeight: '24px', letterSpacing: '0px'   }],
        lg:    ['18px', { lineHeight: '28px', letterSpacing: '-0.1px'}],
        xl:    ['20px', { lineHeight: '28px', letterSpacing: '-0.2px'}],
        '2xl': ['24px', { lineHeight: '32px', letterSpacing: '-0.3px'}],
        '3xl': ['28px', { lineHeight: '36px', letterSpacing: '-0.4px'}],
        '4xl': ['32px', { lineHeight: '40px', letterSpacing: '-0.5px'}],
        '5xl': ['40px', { lineHeight: '48px', letterSpacing: '-0.8px'}],
        '6xl': ['48px', { lineHeight: '56px', letterSpacing: '-1px'  }],
      },

      // ─── Shadows (cross-platform) ─────────────────────────────────────────────
      boxShadow: {
        xs:  '0 1px 2px 0 rgba(0,0,0,0.05)',
        sm:  '0 1px 3px 0 rgba(0,0,0,0.10), 0 1px 2px -1px rgba(0,0,0,0.10)',
        md:  '0 4px 6px -1px rgba(0,0,0,0.10), 0 2px 4px -2px rgba(0,0,0,0.10)',
        lg:  '0 10px 15px -3px rgba(0,0,0,0.10), 0 4px 6px -4px rgba(0,0,0,0.10)',
        xl:  '0 20px 25px -5px rgba(0,0,0,0.10), 0 8px 10px -6px rgba(0,0,0,0.10)',
        '2xl':'0 25px 50px -12px rgba(0,0,0,0.25)',
        inner:'inset 0 2px 4px 0 rgba(0,0,0,0.06)',
        none: 'none',
      },
    },
  },

  plugins: [],
};
