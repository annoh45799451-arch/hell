/**
 * spacing.ts — Design Token: Spacing Scale
 * ─────────────────────────────────────────────────────────────────────────────
 * 8-pt grid system. Every value is a multiple of 4 (base unit).
 * Mirrors the spacing scale in tailwind.config.js for full consistency.
 *
 * Usage:
 *   import { spacing } from '@/theme/spacing';
 *   style={{ padding: spacing[4], marginBottom: spacing[6] }}
 * ─────────────────────────────────────────────────────────────────────────────
 */

export const spacing = {
  // ─── Base ──────────────────────────────────────────────────────────────────
  px:  1,
  0:   0,
  0.5: 2,
  1:   4,
  1.5: 6,
  2:   8,
  2.5: 10,
  3:   12,
  3.5: 14,
  4:   16,
  5:   20,
  6:   24,
  7:   28,
  8:   32,
  9:   36,
  10:  40,
  11:  44,
  12:  48,
  14:  56,
  16:  64,
  20:  80,
  24:  96,
  28:  112,
  32:  128,
} as const;

// ─── Semantic Aliases ─────────────────────────────────────────────────────────
/** Component-level padding / gap presets */
export const inset = {
  /** 4px — tight inline padding */
  xs:  spacing[1],
  /** 8px — compact padding */
  sm:  spacing[2],
  /** 12px — default inline padding */
  md:  spacing[3],
  /** 16px — standard container padding */
  lg:  spacing[4],
  /** 24px — generous container padding */
  xl:  spacing[6],
  /** 32px — section-level padding */
  '2xl': spacing[8],
  /** 48px — page-level padding */
  '3xl': spacing[12],
} as const;

/** Gap between sibling elements */
export const gap = {
  xs:  spacing[1],   //  4px
  sm:  spacing[2],   //  8px
  md:  spacing[3],   // 12px
  lg:  spacing[4],   // 16px
  xl:  spacing[6],   // 24px
  '2xl': spacing[8], // 32px
} as const;

/** Vertical rhythm — space between stacked sections / groups */
export const stack = {
  xs:  spacing[2],   //  8px
  sm:  spacing[4],   // 16px
  md:  spacing[6],   // 24px
  lg:  spacing[8],   // 32px
  xl:  spacing[12],  // 48px
  '2xl': spacing[20],// 80px
} as const;

/** Hit-target sizes (minimum 44px per WCAG / HIG / Material) */
export const hitSlop = {
  sm:    { top: 4,  right: 4,  bottom: 4,  left: 4  },
  md:    { top: 8,  right: 8,  bottom: 8,  left: 8  },
  lg:    { top: 12, right: 12, bottom: 12, left: 12 },
} as const;

/** Border radius tokens */
export const radius = {
  none: 0,
  xs:   4,
  sm:   6,
  md:   8,
  lg:   12,
  xl:   16,
  '2xl':20,
  '3xl':24,
  full: 9999,
} as const;

/** Minimum touch-target height (WCAG 2.5.5 Target Size) */
export const touchTarget = {
  sm:  36,
  md:  44,  // ◀ default — satisfies HIG + Material
  lg:  52,
  xl:  60,
} as const;

// ─── Type Exports ─────────────────────────────────────────────────────────────
export type SpacingScale  = typeof spacing;
export type InsetScale    = typeof inset;
export type GapScale      = typeof gap;
export type StackScale    = typeof stack;
export type RadiusScale   = typeof radius;
