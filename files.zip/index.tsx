/**
 * Button — Component
 * ─────────────────────────────────────────────────────────────────────────────
 * Variants : primary | secondary | ghost | destructive
 * Sizes    : sm | md | lg
 * States   : default | hover | pressed | loading | disabled
 *
 * Built with NativeWind v4 (className) + Animated for press feedback.
 *
 * Usage:
 *   <Button variant="primary" size="md" onPress={handlePress}>
 *     Get Started
 *   </Button>
 *
 *   <Button variant="ghost" size="sm" leftIcon={<Icon />} loading>
 *     Processing…
 *   </Button>
 * ─────────────────────────────────────────────────────────────────────────────
 */
import React, { useRef, useCallback } from 'react';
import {
  Animated,
  Pressable,
  Text,
  View,
  ActivityIndicator,
  PressableProps,
  ViewStyle,
  TextStyle,
  StyleProp,
} from 'react-native';

// ─── Types ────────────────────────────────────────────────────────────────────
export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'destructive';
export type ButtonSize    = 'sm' | 'md' | 'lg';

export interface ButtonProps extends Omit<PressableProps, 'style'> {
  /** Visual style variant */
  variant?: ButtonVariant;
  /** Size preset */
  size?: ButtonSize;
  /** Show spinner and disable interaction */
  loading?: boolean;
  /** Leading icon element */
  leftIcon?: React.ReactNode;
  /** Trailing icon element */
  rightIcon?: React.ReactNode;
  /** Stretch to fill container width */
  fullWidth?: boolean;
  /** Override container style */
  style?: StyleProp<ViewStyle>;
  /** Override label style */
  labelStyle?: StyleProp<TextStyle>;
  /** Button label */
  children: React.ReactNode;
}

// ─── Style Maps (Tailwind class strings) ─────────────────────────────────────
const containerBase =
  'flex-row items-center justify-center rounded-xl overflow-hidden';

const variantContainer: Record<ButtonVariant, string> = {
  primary:     'bg-primary-500 active:bg-primary-700',
  secondary:   'bg-neutral-100 border border-neutral-200 active:bg-neutral-200',
  ghost:       'bg-transparent active:bg-neutral-100',
  destructive: 'bg-error-500 active:bg-error-700',
};

const variantContainerDisabled: Record<ButtonVariant, string> = {
  primary:     'bg-neutral-200',
  secondary:   'bg-neutral-100 border border-neutral-200',
  ghost:       'bg-transparent',
  destructive: 'bg-neutral-200',
};

const sizeContainer: Record<ButtonSize, string> = {
  sm: 'h-9 px-3 gap-1.5',
  md: 'h-11 px-4 gap-2',
  lg: 'h-14 px-6 gap-2.5',
};

const variantLabel: Record<ButtonVariant, string> = {
  primary:     'text-white',
  secondary:   'text-neutral-800',
  ghost:       'text-primary-600',
  destructive: 'text-white',
};

const variantLabelDisabled: Record<ButtonVariant, string> = {
  primary:     'text-neutral-400',
  secondary:   'text-neutral-400',
  ghost:       'text-neutral-400',
  destructive: 'text-neutral-400',
};

const sizeLabel: Record<ButtonSize, string> = {
  sm: 'text-xs font-semibold tracking-wide',
  md: 'text-sm font-semibold tracking-wide',
  lg: 'text-md font-semibold tracking-wide',
};

const spinnerColor: Record<ButtonVariant, string> = {
  primary:     '#FFFFFF',
  secondary:   '#6366F1',
  ghost:       '#6366F1',
  destructive: '#FFFFFF',
};

const spinnerSize: Record<ButtonSize, number> = {
  sm: 14,
  md: 16,
  lg: 20,
};

// ─── Component ────────────────────────────────────────────────────────────────
export const Button = React.memo(function Button({
  variant   = 'primary',
  size      = 'md',
  loading   = false,
  leftIcon,
  rightIcon,
  fullWidth = false,
  disabled,
  style,
  labelStyle,
  children,
  onPress,
  onPressIn,
  onPressOut,
  ...rest
}: ButtonProps) {
  const scale = useRef(new Animated.Value(1)).current;

  const isDisabled = disabled || loading;

  const handlePressIn = useCallback(() => {
    Animated.spring(scale, {
      toValue:         0.97,
      useNativeDriver: true,
      speed:           50,
      bounciness:      4,
    }).start();
    onPressIn?.();
  }, [scale, onPressIn]);

  const handlePressOut = useCallback(() => {
    Animated.spring(scale, {
      toValue:         1,
      useNativeDriver: true,
      speed:           50,
      bounciness:      4,
    }).start();
    onPressOut?.();
  }, [scale, onPressOut]);

  // ── Compute class strings ─────────────────────────────────────────────────
  const containerCls = [
    containerBase,
    isDisabled ? variantContainerDisabled[variant] : variantContainer[variant],
    sizeContainer[size],
    fullWidth ? 'w-full' : 'self-start',
    isDisabled ? 'opacity-60' : 'opacity-100',
  ].join(' ');

  const labelCls = [
    isDisabled ? variantLabelDisabled[variant] : variantLabel[variant],
    sizeLabel[size],
  ].join(' ');

  return (
    <Animated.View style={[{ transform: [{ scale }] }, style]}>
      <Pressable
        className={containerCls}
        disabled={isDisabled}
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        accessibilityRole="button"
        accessibilityState={{ disabled: isDisabled, busy: loading }}
        {...rest}
      >
        {/* Leading icon or spinner */}
        {loading ? (
          <ActivityIndicator
            size={spinnerSize[size]}
            color={spinnerColor[variant]}
          />
        ) : leftIcon ? (
          <View className="flex-shrink-0">{leftIcon}</View>
        ) : null}

        {/* Label */}
        <Text className={labelCls} style={labelStyle} numberOfLines={1}>
          {children}
        </Text>

        {/* Trailing icon */}
        {rightIcon && !loading ? (
          <View className="flex-shrink-0">{rightIcon}</View>
        ) : null}
      </Pressable>
    </Animated.View>
  );
});

// ─── Convenience Aliases ──────────────────────────────────────────────────────
/** Pre-configured primary button */
export const PrimaryButton  = (p: Omit<ButtonProps, 'variant'>) =>
  <Button variant="primary"     {...p} />;

/** Pre-configured secondary button */
export const SecondaryButton = (p: Omit<ButtonProps, 'variant'>) =>
  <Button variant="secondary"   {...p} />;

/** Pre-configured ghost / text button */
export const GhostButton     = (p: Omit<ButtonProps, 'variant'>) =>
  <Button variant="ghost"       {...p} />;

/** Pre-configured destructive button */
export const DestructiveButton = (p: Omit<ButtonProps, 'variant'>) =>
  <Button variant="destructive" {...p} />;
