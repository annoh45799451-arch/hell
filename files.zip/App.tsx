/**
 * App.tsx — Component Library Preview Screen
 * ─────────────────────────────────────────────────────────────────────────────
 * Run this to visually confirm every component is wired correctly.
 * Delete / replace with your real root once confirmed.
 * ─────────────────────────────────────────────────────────────────────────────
 */
import React from 'react';
import { ScrollView, View, SafeAreaView } from 'react-native';
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from '@expo-google-fonts/inter';
import { SpaceMono_400Regular } from '@expo-google-fonts/space-mono';

// ◀ NativeWind v4 — import the global CSS at root
import './global.css';

import {
  Button, PrimaryButton, SecondaryButton, GhostButton, DestructiveButton,
  Card,
  Badge,
  Input,
  H2, H3, H4, BodyMd, Caption, Overline,
} from '@/components';

export default function App() {
  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
    SpaceMono_400Regular,
  });

  if (!fontsLoaded) return null;

  return (
    <SafeAreaView className="flex-1 bg-neutral-50">
      <ScrollView
        className="flex-1"
        contentContainerClassName="px-4 py-8 gap-8"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Section: Typography ──────────────────────────────────────────── */}
        <View className="gap-3">
          <Overline color="tertiary">Design System</Overline>
          <H2>Component Library</H2>
          <BodyMd color="secondary">
            Every component is fully typed, accessible, and driven by NativeWind v4.
          </BodyMd>
        </View>

        {/* ── Section: Buttons ─────────────────────────────────────────────── */}
        <View className="gap-4">
          <H3>Buttons</H3>

          <View className="gap-3">
            <H4 color="secondary">Variants</H4>
            <View className="gap-2">
              <PrimaryButton size="md">Primary Action</PrimaryButton>
              <SecondaryButton size="md">Secondary Action</SecondaryButton>
              <GhostButton size="md">Ghost / Text</GhostButton>
              <DestructiveButton size="md">Delete Account</DestructiveButton>
            </View>
          </View>

          <View className="gap-3">
            <H4 color="secondary">Sizes</H4>
            <View className="flex-row flex-wrap gap-2 items-center">
              <Button variant="primary" size="sm">Small</Button>
              <Button variant="primary" size="md">Medium</Button>
              <Button variant="primary" size="lg">Large</Button>
            </View>
          </View>

          <View className="gap-3">
            <H4 color="secondary">States</H4>
            <View className="gap-2">
              <Button variant="primary" size="md" loading>Processing…</Button>
              <Button variant="primary" size="md" disabled>Disabled</Button>
              <Button variant="primary" size="md" fullWidth>Full Width</Button>
            </View>
          </View>
        </View>

        {/* ── Section: Cards ───────────────────────────────────────────────── */}
        <View className="gap-4">
          <H3>Cards</H3>

          {/* Info card */}
          <Card elevation="sm">
            <Card.Header
              title="Pro Plan"
              subtitle="Billed monthly"
              right={<Badge variant="success">Active</Badge>}
            />
            <Card.Body>
              <BodyMd color="secondary">
                Unlimited projects, priority support, and advanced analytics.
              </BodyMd>
            </Card.Body>
            <Card.Footer divided>
              <GhostButton size="sm">Cancel</GhostButton>
              <PrimaryButton size="sm">Manage Plan</PrimaryButton>
            </Card.Footer>
          </Card>

          {/* Pressable card */}
          <Card elevation="md" onPress={() => {}}>
            <Card.Body>
              <View className="gap-1">
                <Caption color="tertiary">Tap anywhere</Caption>
                <H4>Pressable Card</H4>
                <BodyMd color="secondary">
                  Cards with onPress spring-animate on interaction.
                </BodyMd>
              </View>
            </Card.Body>
          </Card>

          {/* Flat outlined */}
          <Card elevation="none" variant="outlined">
            <Card.Body>
              <H4>Outlined / Flat</H4>
              <BodyMd color="secondary">Zero shadow — for tight, compact UIs.</BodyMd>
            </Card.Body>
          </Card>
        </View>

        {/* ── Section: Badges ──────────────────────────────────────────────── */}
        <View className="gap-4">
          <H3>Badges</H3>
          <View className="flex-row flex-wrap gap-2">
            <Badge variant="default" badgeStyle="subtle">Default</Badge>
            <Badge variant="primary" badgeStyle="subtle">Primary</Badge>
            <Badge variant="success" badgeStyle="subtle" dot>Active</Badge>
            <Badge variant="warning" badgeStyle="subtle" dot>Pending</Badge>
            <Badge variant="error"   badgeStyle="subtle" dot>Failed</Badge>
            <Badge variant="info"    badgeStyle="subtle">Info</Badge>
          </View>
          <View className="flex-row flex-wrap gap-2">
            <Badge variant="success" badgeStyle="solid">Verified</Badge>
            <Badge variant="error"   badgeStyle="outline">Rejected</Badge>
            <Badge variant="primary" badgeStyle="outline" size="sm">New</Badge>
          </View>
        </View>

        {/* ── Section: Inputs ──────────────────────────────────────────────── */}
        <View className="gap-4">
          <H3>Inputs</H3>
          <Input
            label="Email"
            placeholder="you@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
            required
            hint="We'll never share your email."
          />
          <Input
            label="Password"
            placeholder="••••••••"
            secureTextEntry
            secureToggle
            required
          />
          <Input
            label="Promo Code"
            placeholder="SUMMER2024"
            error="This code has expired."
            autoCapitalize="characters"
          />
          <Input
            label="Notes"
            placeholder="Optional"
            variant="filled"
            hint="Filled variant — great for forms on white backgrounds."
          />
        </View>

        {/* ── Bottom spacer ─────────────────────────────────────────────────── */}
        <View className="h-8" />
      </ScrollView>
    </SafeAreaView>
  );
}
