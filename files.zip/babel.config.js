// babel.config.js
// NativeWind v4 requires the nativewind/babel plugin.
// Make sure 'nativewind' is listed AFTER other Babel transforms.
module.exports = function (api) {
  api.cache(true);
  return {
    presets: [
      ['babel-preset-expo', { jsxImportSource: 'nativewind' }],
      'nativewind/babel',
    ],
  };
};
