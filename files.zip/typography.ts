/**
 * typography.ts — Design Token: Type System
 * ─────────────────────────────────────────────────────────────────────────────
 * Complete typographic scale + semantic text-style presets.
 * Fonts: Inter (weights 400-700) + SpaceMono (mono/code).
 *
 * Setup — add to your App.tsx / _layout.tsx root:
 *
 *   import { useFonts, Inter_400Regular, Inter_500Medium,
 *            Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
 *   import { SpaceMono_400Regular } from '@expo-google-fonts/space-mono';
 *
 * Usage:
 *   import { textStyles } from '@/theme/typography';
 *   <Text style={textStyles.headingLg}>Hello</Text>
 * ─────────────────────────────────────────────────────────────────────────────
 */
import { Platform, TextStyle } from 'react-native';

// ─── Font Family Constants ────────────────────────────────────────────────────
export const fontFamily = {
  sans: {
    regular:  'Inter_400Regular',
    medium:   'Inter_500Medium',
    semibold: 'Inter_600SemiBold',
    bold:     'Inter_700Bold',
  },
  mono: {
    regular: 'SpaceMono_400Regular',
  },
  /** System fallback stack (used before fonts are loaded) */
  system: Platform.select({ ios: 'System', android: 'sans-serif', default: 'System' }),
} as const;

// ─── Font Size + Line Height Scale ───────────────────────────────────────────
export const typeScale = {
  '2xs': { fontSize: 10, lineHeight: 14 },
  xs:    { fontSize: 12, lineHeight: 16 },
  sm:    { fontSize: 14, lineHeight: 20 },
  md:    { fontSize: 16, lineHeight: 24 },
  lg:    { fontSize: 18, lineHeight: 28 },
  xl:    { fontSize: 20, lineHeight: 28 },
  '2xl': { fontSize: 24, lineHeight: 32 },
  '3xl': { fontSize: 28, lineHeight: 36 },
  '4xl': { fontSize: 32, lineHeight: 40 },
  '5xl': { fontSize: 40, lineHeight: 48 },
  '6xl': { fontSize: 48, lineHeight: 56 },
} as const;

// ─── Letter Spacing ───────────────────────────────────────────────────────────
export const letterSpacing = {
  tighter: -0.8,
  tight:   -0.4,
  snug:    -0.2,
  normal:   0,
  wide:     0.2,
  wider:    0.4,
  widest:   0.8,
  caps:     1.2,
} as const;

// ─── Font Weight (RN uses string) ─────────────────────────────────────────────
export const fontWeight = {
  regular:  '400' as TextStyle['fontWeight'],
  medium:   '500' as TextStyle['fontWeight'],
  semibold: '600' as TextStyle['fontWeight'],
  bold:     '700' as TextStyle['fontWeight'],
} as const;

// ─── Semantic Text Styles ─────────────────────────────────────────────────────
// Ready-to-use presets that compose the primitives above.
export const textStyles = {
  // ── Display / Hero ──────────────────────────────────────────────────────────
  displayXl: {
    fontFamily:    fontFamily.sans.bold,
    fontSize:      typeScale['6xl'].fontSize,
    lineHeight:    typeScale['6xl'].lineHeight,
    letterSpacing: letterSpacing.tighter,
    fontWeight:    fontWeight.bold,
  } satisfies TextStyle,

  displayLg: {
    fontFamily:    fontFamily.sans.bold,
    fontSize:      typeScale['5xl'].fontSize,
    lineHeight:    typeScale['5xl'].lineHeight,
    letterSpacing: letterSpacing.tighter,
    fontWeight:    fontWeight.bold,
  } satisfies TextStyle,

  displayMd: {
    fontFamily:    fontFamily.sans.bold,
    fontSize:      typeScale['4xl'].fontSize,
    lineHeight:    typeScale['4xl'].lineHeight,
    letterSpacing: letterSpacing.tight,
    fontWeight:    fontWeight.bold,
  } satisfies TextStyle,

  // ── Heading ─────────────────────────────────────────────────────────────────
  headingXl: {
    fontFamily:    fontFamily.sans.bold,
    fontSize:      typeScale['3xl'].fontSize,
    lineHeight:    typeScale['3xl'].lineHeight,
    letterSpacing: letterSpacing.tight,
    fontWeight:    fontWeight.bold,
  } satisfies TextStyle,

  headingLg: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale['2xl'].fontSize,
    lineHeight:    typeScale['2xl'].lineHeight,
    letterSpacing: letterSpacing.snug,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  headingMd: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale.xl.fontSize,
    lineHeight:    typeScale.xl.lineHeight,
    letterSpacing: letterSpacing.snug,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  headingSm: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale.lg.fontSize,
    lineHeight:    typeScale.lg.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  headingXs: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale.md.fontSize,
    lineHeight:    typeScale.md.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  // ── Body ────────────────────────────────────────────────────────────────────
  bodyLg: {
    fontFamily:    fontFamily.sans.regular,
    fontSize:      typeScale.lg.fontSize,
    lineHeight:    typeScale.lg.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.regular,
  } satisfies TextStyle,

  bodyMd: {
    fontFamily:    fontFamily.sans.regular,
    fontSize:      typeScale.md.fontSize,
    lineHeight:    typeScale.md.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.regular,
  } satisfies TextStyle,

  bodySm: {
    fontFamily:    fontFamily.sans.regular,
    fontSize:      typeScale.sm.fontSize,
    lineHeight:    typeScale.sm.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.regular,
  } satisfies TextStyle,

  bodyXs: {
    fontFamily:    fontFamily.sans.regular,
    fontSize:      typeScale.xs.fontSize,
    lineHeight:    typeScale.xs.lineHeight,
    letterSpacing: letterSpacing.wide,
    fontWeight:    fontWeight.regular,
  } satisfies TextStyle,

  // ── Label / UI ──────────────────────────────────────────────────────────────
  labelLg: {
    fontFamily:    fontFamily.sans.medium,
    fontSize:      typeScale.md.fontSize,
    lineHeight:    typeScale.md.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.medium,
  } satisfies TextStyle,

  labelMd: {
    fontFamily:    fontFamily.sans.medium,
    fontSize:      typeScale.sm.fontSize,
    lineHeight:    typeScale.sm.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.medium,
  } satisfies TextStyle,

  labelSm: {
    fontFamily:    fontFamily.sans.medium,
    fontSize:      typeScale.xs.fontSize,
    lineHeight:    typeScale.xs.lineHeight,
    letterSpacing: letterSpacing.wide,
    fontWeight:    fontWeight.medium,
  } satisfies TextStyle,

  labelXs: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale['2xs'].fontSize,
    lineHeight:    typeScale['2xs'].lineHeight,
    letterSpacing: letterSpacing.caps,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  // ── Overline / Caption / Code ─────────────────────────────────────────────
  overline: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale.xs.fontSize,
    lineHeight:    typeScale.xs.lineHeight,
    letterSpacing: letterSpacing.caps,
    fontWeight:    fontWeight.semibold,
    textTransform: 'uppercase' as const,
  } satisfies TextStyle,

  caption: {
    fontFamily:    fontFamily.sans.regular,
    fontSize:      typeScale.xs.fontSize,
    lineHeight:    typeScale.xs.lineHeight,
    letterSpacing: letterSpacing.wide,
    fontWeight:    fontWeight.regular,
  } satisfies TextStyle,

  code: {
    fontFamily:    fontFamily.mono.regular,
    fontSize:      typeScale.sm.fontSize,
    lineHeight:    typeScale.sm.lineHeight,
    letterSpacing: letterSpacing.normal,
    fontWeight:    fontWeight.regular,
  } satisfies TextStyle,

  // ── Button Labels ───────────────────────────────────────────────────────────
  buttonLg: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale.md.fontSize,
    lineHeight:    typeScale.md.lineHeight,
    letterSpacing: letterSpacing.wide,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  buttonMd: {
    fontFamily:    fontFamily.sans.semibold,
    fontSize:      typeScale.sm.fontSize,
    lineHeight:    typeScale.sm.lineHeight,
    letterSpacing: letterSpacing.wide,
    fontWeight:    fontWeight.semibold,
  } satisfies TextStyle,

  buttonSm: {
    fontFamily:    fontFamily.sans.medium,
    fontSize:      typeScale.xs.fontSize,
    lineHeight:    typeScale.xs.lineHeight,
    letterSpacing: letterSpacing.wider,
    fontWeight:    fontWeight.medium,
  } satisfies TextStyle,
} as const;

// ─── Type Exports ─────────────────────────────────────────────────────────────
export type TextStyleKey    = keyof typeof textStyles;
export type TypeScaleKey    = keyof typeof typeScale;
export type FontFamilyGroup = keyof typeof fontFamily;
