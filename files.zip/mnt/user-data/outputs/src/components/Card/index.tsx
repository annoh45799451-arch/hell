/**
 * Card — Component
 * ─────────────────────────────────────────────────────────────────────────────
 * A composable surface component with:
 *   - 5 elevation levels (flat → elevated → floating)
 *   - Outlined + filled variants
 *   - Pressable mode with spring animation
 *   - Slot-based composition: Card.Header, Card.Body, Card.Footer, Card.Image
 *
 * Usage (static):
 *   <Card elevation="md">
 *     <Card.Header title="Plan Summary" subtitle="Monthly" />
 *     <Card.Body>…content…</Card.Body>
 *     <Card.Footer><Button>Upgrade</Button></Card.Footer>
 *   </Card>
 *
 * Usage (pressable):
 *   <Card elevation="sm" onPress={() => router.push('/detail')}>
 *     <Card.Body>…</Card.Body>
 *   </Card>
 * ─────────────────────────────────────────────────────────────────────────────
 */
import React, { useRef, useCallback } from 'react';
import {
  Animated,
  Pressable,
  View,
  Text,
  Image,
  ViewProps,
  PressableProps,
  ImageSourcePropType,
  StyleProp,
  ViewStyle,
  ImageStyle,
  TextStyle,
  Platform,
  StyleSheet,
} from 'react-native';

// ─── Types ────────────────────────────────────────────────────────────────────
export type CardElevation = 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type CardVariant   = 'filled' | 'outlined' | 'ghost';

export interface CardProps {
  /** Shadow depth */
  elevation?: CardElevation;
  /** Surface style */
  variant?: CardVariant;
  /** Make the card tappable */
  onPress?: PressableProps['onPress'];
  /** Fully round corners (pill-card) */
  rounded?: boolean;
  /** Override outer container style */
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
}

// ─── Shadow Maps (platform-aware) ────────────────────────────────────────────
const iosShadow: Record<CardElevation, ViewStyle> = {
  none: {},
  xs:   { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2  },
  sm:   { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 4  },
  md:   { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.10, shadowRadius: 8  },
  lg:   { shadowColor: '#000', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.12, shadowRadius: 16 },
  xl:   { shadowColor: '#000', shadowOffset: { width: 0, height:16 }, shadowOpacity: 0.14, shadowRadius: 24 },
};

const androidElevation: Record<CardElevation, number> = {
  none: 0,
  xs:   2,
  sm:   4,
  md:   8,
  lg:   16,
  xl:   24,
};

// ─── Tailwind classes ─────────────────────────────────────────────────────────
const variantCls: Record<CardVariant, string> = {
  filled:   'bg-white',
  outlined: 'bg-white border border-neutral-200',
  ghost:    'bg-transparent',
};

const radiusCls = {
  default: 'rounded-2xl',
  pill:    'rounded-3xl',
};

// ─── Sub-components ──────────────────────────────────────────────────────────

// Card.Image
interface CardImageProps {
  source: ImageSourcePropType;
  aspectRatio?: number;
  style?: StyleProp<ImageStyle>;
}
function CardImage({ source, aspectRatio = 16 / 9, style }: CardImageProps) {
  return (
    <Image
      source={source}
      style={[{ width: '100%', aspectRatio }, style]}
      resizeMode="cover"
      className="rounded-t-2xl"
    />
  );
}

// Card.Header
interface CardHeaderProps {
  title?: string;
  subtitle?: string;
  right?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  titleStyle?: StyleProp<TextStyle>;
  subtitleStyle?: StyleProp<TextStyle>;
}
function CardHeader({
  title,
  subtitle,
  right,
  style,
  titleStyle,
  subtitleStyle,
}: CardHeaderProps) {
  return (
    <View
      className="flex-row items-start justify-between px-4 pt-4 pb-2"
      style={style}
    >
      <View className="flex-1 mr-2">
        {title ? (
          <Text
            className="text-neutral-900 text-lg font-semibold leading-7 tracking-tight"
            style={titleStyle}
            numberOfLines={2}
          >
            {title}
          </Text>
        ) : null}
        {subtitle ? (
          <Text
            className="text-neutral-500 text-sm font-normal leading-5 mt-0.5"
            style={subtitleStyle}
            numberOfLines={1}
          >
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right ? <View className="flex-shrink-0 mt-0.5">{right}</View> : null}
    </View>
  );
}

// Card.Body
interface CardBodyProps {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  padded?: boolean;
}
function CardBody({ children, style, padded = true }: CardBodyProps) {
  return (
    <View
      className={padded ? 'px-4 py-3' : ''}
      style={style}
    >
      {children}
    </View>
  );
}

// Card.Divider
function CardDivider() {
  return <View className="h-px bg-neutral-100 mx-4" />;
}

// Card.Footer
interface CardFooterProps {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  /** Add top divider */
  divided?: boolean;
}
function CardFooter({ children, style, divided = false }: CardFooterProps) {
  return (
    <>
      {divided && <CardDivider />}
      <View
        className="flex-row items-center justify-end gap-2 px-4 py-3"
        style={style}
      >
        {children}
      </View>
    </>
  );
}

// ─── Main Card Component ──────────────────────────────────────────────────────
function CardRoot({
  elevation = 'sm',
  variant   = 'filled',
  onPress,
  rounded   = false,
  style,
  children,
}: CardProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = useCallback(() => {
    if (!onPress) return;
    Animated.spring(scaleAnim, {
      toValue:         0.985,
      useNativeDriver: true,
      speed:           40,
      bounciness:      2,
    }).start();
  }, [scaleAnim, onPress]);

  const handlePressOut = useCallback(() => {
    if (!onPress) return;
    Animated.spring(scaleAnim, {
      toValue:         1,
      useNativeDriver: true,
      speed:           40,
      bounciness:      2,
    }).start();
  }, [scaleAnim, onPress]);

  // ── Build shadow style ───────────────────────────────────────────────────
  const shadowStyle: ViewStyle =
    Platform.OS === 'ios'
      ? iosShadow[elevation]
      : { elevation: androidElevation[elevation] };

  const containerCls = [
    variantCls[variant],
    rounded ? radiusCls.pill : radiusCls.default,
    'overflow-hidden',
  ].join(' ');

  const inner = (
    <Animated.View
      style={[shadowStyle, { transform: [{ scale: scaleAnim }] }, style]}
    >
      <View className={containerCls}>
        {children}
      </View>
    </Animated.View>
  );

  if (onPress) {
    return (
      <Pressable
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        accessibilityRole="button"
      >
        {inner}
      </Pressable>
    );
  }

  return inner;
}

// ─── Compound Export ──────────────────────────────────────────────────────────
export const Card = Object.assign(CardRoot, {
  Image:   CardImage,
  Header:  CardHeader,
  Body:    CardBody,
  Footer:  CardFooter,
  Divider: CardDivider,
});
