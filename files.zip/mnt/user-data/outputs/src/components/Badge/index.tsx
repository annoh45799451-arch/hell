/**
 * Badge — Component
 * ─────────────────────────────────────────────────────────────────────────────
 * Compact label component for statuses, counts, and tags.
 *
 * Variants: default | success | warning | error | info
 * Styles  : solid | subtle | outline
 * Size    : sm | md
 *
 * Usage:
 *   <Badge variant="success">Active</Badge>
 *   <Badge variant="error" style="outline" dot>Failed</Badge>
 *   <Badge variant="info" size="sm">3</Badge>
 * ─────────────────────────────────────────────────────────────────────────────
 */
import React from 'react';
import { View, Text, ViewStyle, TextStyle, StyleProp } from 'react-native';

export type BadgeVariant = 'default' | 'primary' | 'success' | 'warning' | 'error' | 'info';
export type BadgeStyle   = 'solid' | 'subtle' | 'outline';
export type BadgeSize    = 'sm' | 'md';

export interface BadgeProps {
  variant?: BadgeVariant;
  badgeStyle?: BadgeStyle;
  size?: BadgeSize;
  /** Show a leading status dot */
  dot?: boolean;
  style?: StyleProp<ViewStyle>;
  labelStyle?: StyleProp<TextStyle>;
  children: React.ReactNode;
}

// ─── Style Maps ───────────────────────────────────────────────────────────────
const solidContainer: Record<BadgeVariant, string> = {
  default: 'bg-neutral-700',
  primary: 'bg-primary-500',
  success: 'bg-success-500',
  warning: 'bg-warning-500',
  error:   'bg-error-500',
  info:    'bg-info-500',
};
const solidLabel: Record<BadgeVariant, string> = {
  default: 'text-white',
  primary: 'text-white',
  success: 'text-white',
  warning: 'text-white',
  error:   'text-white',
  info:    'text-white',
};

const subtleContainer: Record<BadgeVariant, string> = {
  default: 'bg-neutral-100',
  primary: 'bg-primary-50',
  success: 'bg-success-50',
  warning: 'bg-warning-50',
  error:   'bg-error-50',
  info:    'bg-info-50',
};
const subtleLabel: Record<BadgeVariant, string> = {
  default: 'text-neutral-700',
  primary: 'text-primary-700',
  success: 'text-success-700',
  warning: 'text-warning-700',
  error:   'text-error-700',
  info:    'text-info-700',
};

const outlineContainer: Record<BadgeVariant, string> = {
  default: 'border border-neutral-300 bg-transparent',
  primary: 'border border-primary-400 bg-transparent',
  success: 'border border-success-500 bg-transparent',
  warning: 'border border-warning-500 bg-transparent',
  error:   'border border-error-500 bg-transparent',
  info:    'border border-info-500 bg-transparent',
};
const outlineLabel: Record<BadgeVariant, string> = {
  default: 'text-neutral-700',
  primary: 'text-primary-600',
  success: 'text-success-600',
  warning: 'text-warning-600',
  error:   'text-error-600',
  info:    'text-info-600',
};
const dotColor: Record<BadgeVariant, string> = {
  default: 'bg-neutral-500',
  primary: 'bg-primary-500',
  success: 'bg-success-500',
  warning: 'bg-warning-500',
  error:   'bg-error-500',
  info:    'bg-info-500',
};

const sizeContainer: Record<BadgeSize, string> = {
  sm: 'px-1.5 py-0.5 rounded-full gap-1',
  md: 'px-2 py-1 rounded-full gap-1.5',
};
const sizeLabel: Record<BadgeSize, string> = {
  sm: 'text-2xs font-semibold tracking-wide',
  md: 'text-xs font-semibold tracking-wide',
};
const sizeDot: Record<BadgeSize, string> = {
  sm: 'w-1 h-1 rounded-full',
  md: 'w-1.5 h-1.5 rounded-full',
};

export function Badge({
  variant    = 'default',
  badgeStyle = 'subtle',
  size       = 'md',
  dot        = false,
  style,
  labelStyle,
  children,
}: BadgeProps) {
  const containerMap = {
    solid:   solidContainer,
    subtle:  subtleContainer,
    outline: outlineContainer,
  }[badgeStyle];

  const labelMap = {
    solid:   solidLabel,
    subtle:  subtleLabel,
    outline: outlineLabel,
  }[badgeStyle];

  const containerCls = [
    'flex-row items-center',
    sizeContainer[size],
    containerMap[variant],
  ].join(' ');

  return (
    <View className={containerCls} style={style}>
      {dot && (
        <View className={`${sizeDot[size]} ${dotColor[variant]}`} />
      )}
      <Text
        className={`${sizeLabel[size]} ${labelMap[variant]}`}
        style={labelStyle}
        numberOfLines={1}
      >
        {children}
      </Text>
    </View>
  );
}
