/**
 * Input — Component
 * ─────────────────────────────────────────────────────────────────────────────
 * Controlled text input with:
 *   - Label + required indicator
 *   - Helper / hint text
 *   - Error state + message
 *   - Left / right adornments (icons, units)
 *   - Filled + outlined variants
 *   - Password toggle
 *
 * Usage:
 *   <Input
 *     label="Email"
 *     placeholder="you@example.com"
 *     value={email}
 *     onChangeText={setEmail}
 *     keyboardType="email-address"
 *     leftAdornment={<MailIcon />}
 *     error={errors.email}
 *   />
 * ─────────────────────────────────────────────────────────────────────────────
 */
import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TextInputProps,
  Pressable,
  Animated,
  StyleProp,
  ViewStyle,
} from 'react-native';

export type InputVariant = 'outlined' | 'filled';
export type InputSize    = 'sm' | 'md' | 'lg';

export interface InputProps extends Omit<TextInputProps, 'style'> {
  label?: string;
  required?: boolean;
  hint?: string;
  error?: string;
  variant?: InputVariant;
  size?: InputSize;
  leftAdornment?: React.ReactNode;
  rightAdornment?: React.ReactNode;
  /** Automatically adds a show/hide eye toggle */
  secureToggle?: boolean;
  style?: StyleProp<ViewStyle>;
}

const sizeInput: Record<InputSize, string> = {
  sm: 'h-9 text-sm',
  md: 'h-11 text-md',
  lg: 'h-14 text-md',
};
const sizePad: Record<InputSize, string> = {
  sm: 'px-3',
  md: 'px-4',
  lg: 'px-4',
};

export function Input({
  label,
  required      = false,
  hint,
  error,
  variant       = 'outlined',
  size          = 'md',
  leftAdornment,
  rightAdornment,
  secureToggle  = false,
  style,
  secureTextEntry,
  onFocus,
  onBlur,
  ...rest
}: InputProps) {
  const [focused, setFocused]       = useState(false);
  const [showText, setShowText]     = useState(false);
  const borderAnim                  = useRef(new Animated.Value(0)).current;

  const handleFocus = useCallback((e: any) => {
    setFocused(true);
    Animated.timing(borderAnim, {
      toValue: 1, duration: 150, useNativeDriver: false,
    }).start();
    onFocus?.(e);
  }, [borderAnim, onFocus]);

  const handleBlur = useCallback((e: any) => {
    setFocused(false);
    Animated.timing(borderAnim, {
      toValue: 0, duration: 150, useNativeDriver: false,
    }).start();
    onBlur?.(e);
  }, [borderAnim, onBlur]);

  const isSecure = secureTextEntry && !showText;

  // ── Container classes ───────────────────────────────────────────────────
  const wrapperBase = 'flex-row items-center rounded-xl overflow-hidden';
  const variantCls  = variant === 'outlined'
    ? error
      ? 'border-2 border-error-500 bg-white'
      : focused
        ? 'border-2 border-primary-500 bg-white'
        : 'border border-neutral-300 bg-white'
    : error
      ? 'bg-error-50 border-b-2 border-error-500'
      : focused
        ? 'bg-neutral-100 border-b-2 border-primary-500'
        : 'bg-neutral-100 border-b border-neutral-300';

  return (
    <View className="gap-1" style={style}>
      {/* Label */}
      {label ? (
        <View className="flex-row items-center gap-0.5">
          <Text className="text-sm font-medium text-neutral-700">{label}</Text>
          {required && (
            <Text className="text-sm font-medium text-error-500 ml-0.5">*</Text>
          )}
        </View>
      ) : null}

      {/* Input row */}
      <View className={`${wrapperBase} ${variantCls}`}>
        {leftAdornment ? (
          <View className="pl-3 pr-1 flex-shrink-0">{leftAdornment}</View>
        ) : null}

        <TextInput
          className={`flex-1 text-neutral-900 font-normal ${sizeInput[size]} ${!leftAdornment && !rightAdornment ? sizePad[size] : 'px-2'}`}
          placeholderTextColor="#9CA3AF"
          secureTextEntry={isSecure}
          onFocus={handleFocus}
          onBlur={handleBlur}
          {...rest}
        />

        {/* Right: custom adornment OR secure toggle */}
        {secureToggle ? (
          <Pressable
            className="pr-3 pl-1 flex-shrink-0"
            onPress={() => setShowText(v => !v)}
            accessibilityLabel={showText ? 'Hide password' : 'Show password'}
          >
            <Text className="text-sm font-medium text-primary-500">
              {showText ? 'Hide' : 'Show'}
            </Text>
          </Pressable>
        ) : rightAdornment ? (
          <View className="pr-3 pl-1 flex-shrink-0">{rightAdornment}</View>
        ) : null}
      </View>

      {/* Hint / Error */}
      {(error || hint) ? (
        <Text
          className={`text-xs font-normal ${error ? 'text-error-600' : 'text-neutral-500'}`}
        >
          {error ?? hint}
        </Text>
      ) : null}
    </View>
  );
}
