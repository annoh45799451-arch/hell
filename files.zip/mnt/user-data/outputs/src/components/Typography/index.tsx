/**
 * Typography — Component
 * ─────────────────────────────────────────────────────────────────────────────
 * Wraps RN Text with semantic style presets from theme/typography.
 *
 * Usage:
 *   <Typography variant="headingLg">Welcome back 👋</Typography>
 *   <Typography variant="bodyMd" color="secondary">
 *     Here's your summary for today.
 *   </Typography>
 * ─────────────────────────────────────────────────────────────────────────────
 */
import React from 'react';
import {
  Text,
  TextProps,
  StyleProp,
  TextStyle,
} from 'react-native';
import { textStyles, TextStyleKey } from '@/theme/typography';
import { semanticColors }          from '@/theme/colors';

type TypographyColor =
  | 'primary'
  | 'secondary'
  | 'tertiary'
  | 'disabled'
  | 'inverse'
  | 'onPrimary'
  | 'error'
  | 'success'
  | 'warning'
  | 'info';

const colorMap: Record<TypographyColor, string> = {
  primary:   semanticColors.textPrimary,
  secondary: semanticColors.textSecondary,
  tertiary:  semanticColors.textTertiary,
  disabled:  semanticColors.textDisabled,
  inverse:   semanticColors.textInverse,
  onPrimary: semanticColors.textOnPrimary,
  error:     '#EF4444',
  success:   '#16A34A',
  warning:   '#CA8A04',
  info:      '#2563EB',
};

export interface TypographyProps extends TextProps {
  /** Semantic text style preset */
  variant?: TextStyleKey;
  /** Semantic color alias */
  color?: TypographyColor;
  /** Align shorthand */
  align?: TextStyle['textAlign'];
  /** Override any style */
  style?: StyleProp<TextStyle>;
  children?: React.ReactNode;
}

export function Typography({
  variant = 'bodyMd',
  color   = 'primary',
  align,
  style,
  children,
  ...rest
}: TypographyProps) {
  const baseStyle = textStyles[variant];

  return (
    <Text
      style={[
        baseStyle,
        { color: colorMap[color] },
        align ? { textAlign: align } : undefined,
        style,
      ]}
      {...rest}
    >
      {children}
    </Text>
  );
}

// ─── Convenience Shortcuts ────────────────────────────────────────────────────
export const Display   = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="displayLg"  {...p} />;
export const H1        = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="headingXl"  {...p} />;
export const H2        = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="headingLg"  {...p} />;
export const H3        = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="headingMd"  {...p} />;
export const H4        = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="headingSm"  {...p} />;
export const BodyLg    = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="bodyLg"     {...p} />;
export const BodyMd    = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="bodyMd"     {...p} />;
export const BodySm    = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="bodySm"     {...p} />;
export const Label     = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="labelMd"    {...p} />;
export const Caption   = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="caption"    {...p} />;
export const Overline  = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="overline"   {...p} />;
export const Code      = (p: Omit<TypographyProps, 'variant'>) => <Typography variant="code"       {...p} />;
