/**
 * @/components — Component Library Barrel Export
 * ─────────────────────────────────────────────────────────────────────────────
 * Single import for every UI component:
 *
 *   import { Button, Card, Badge, Input, Typography } from '@/components';
 *   import { PrimaryButton, H1, BodyMd } from '@/components';
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ─── Button ──────────────────────────────────────────────────────────────────
export {
  Button,
  PrimaryButton,
  SecondaryButton,
  GhostButton,
  DestructiveButton,
} from './Button';
export type { ButtonProps, ButtonVariant, ButtonSize } from './Button';

// ─── Card ─────────────────────────────────────────────────────────────────────
export { Card } from './Card';
export type { CardProps, CardElevation, CardVariant } from './Card';

// ─── Badge ────────────────────────────────────────────────────────────────────
export { Badge } from './Badge';
export type { BadgeProps, BadgeVariant, BadgeStyle, BadgeSize } from './Badge';

// ─── Input ────────────────────────────────────────────────────────────────────
export { Input } from './Input';
export type { InputProps, InputVariant, InputSize } from './Input';

// ─── Typography ───────────────────────────────────────────────────────────────
export {
  Typography,
  Display,
  H1, H2, H3, H4,
  BodyLg, BodyMd, BodySm,
  Label,
  Caption,
  Overline,
  Code,
} from './Typography';
export type { TypographyProps } from './Typography';
